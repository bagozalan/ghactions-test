# Support 

This repo contains supplemental content for the [GitHub Actions learning pathway](https://resources.github.com/learn/pathways). 

**actions-learning-pathway** is not an open source project, but rather supplemental demo content maintained by GitHub staff. We encourage users to direct questions to the [Community of Discussions](https://github.com/orgs/community/discussions/) or reference [GitHub Docs](https://docs.github.com/en). 

## GitHub Support Policy

Support for this project is limited to the resources listed above.
